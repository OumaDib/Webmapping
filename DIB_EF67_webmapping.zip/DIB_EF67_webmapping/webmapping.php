<?php

// pour tester le code on prend ces coordonnees pour le  grand rectangle
$SW=array(-90,90);
$NE=array(-180,180);

$deg_carre=array();
$tabOut=array();


// connexion a notre base de donnee  Recherche_avion
$link =pg_connect("host=localhost port=5432 dbname=Recherche_avion user=postgres password=postgres" );
if(!$link){die('Erreur de connexion');}

// recuperation des coordonnes du rectangle
$SW=pg_escape_string($GET["SW"]); //  FORMAT : SW=(-90,90)
$NEg=pg_escape_string($GET["NE"]); // FORMAT: NE=(-180,180)

//ici on parcourt le rectangle pour construire les degres carres
for($lat=$SW[0]+1;$lat<=$SW[1]-1;$lat++){
  for($long=$NE[0]+1 ;$long<=$NE[1]-1;$long++){
    // on stocke les coordonnees du degre carre dans un array
    $deg_carre[]=(strval($lat),strval($long),strval($lat+1),strval($long+1)
    // redaction de la requete : on compte le nombre d'hypotheses presentes dans le degre carre
    $requete="SELECT COUNT(*) FROM Table_avion WHERE ST_within( geom , ST_MakeEnvelope($lat,$long, $lat+1, $long+1,4326 ) ) "
    // interrogation de la requete SQL
    $result = pg_query($link, $requete );
    if(!$result) { die ('erreur de requête'); }

    // mise en forme du resultat : on retourne dans $tabOut le degre carre ainsi que le resultat de la requete
      while($ligne = pg_fetch_object($result)) {
        $tabOut[]=($deg_carre,strval($ligne));

      }

        }
      }
// on retourne le resultat au format JSON
echo json_encode($tabOut);
?>
